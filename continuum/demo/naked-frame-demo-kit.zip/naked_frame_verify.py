#!/usr/bin/env python3
"""
Continuum · Naked Frame Verifier  (standalone, offline)

Hand this single file and a small provenance record to anyone. They can strip a sealed
frame of all metadata, rename it, recompress it, screenshot it, then run:

    python3 naked_frame_verify.py <frame_image> <record.json>

and watch the provenance recover FROM THE PIXELS ALONE. No network. No Continuum system.
No metadata. Just the bytes and the math.

The record.json is the public verification record for one sealed frame:
    { "phash": "...", "sha256": "...", "shot": "...", "owned_sources": [...],
      "approvals": [...], "consent": "...", "ai_involved": false }

This proves the claim every metadata-based tool cannot make: separate the file from its
paperwork and the proof still survives.
"""
import sys, json, hashlib
import numpy as np
from PIL import Image

def sha256_bytes(raw): return "sha256:" + hashlib.sha256(raw).hexdigest()

def _to_gray_32(img):
    if img.ndim == 3:
        g = 0.2126*img[...,0] + 0.7152*img[...,1] + 0.0722*img[...,2]
    else: g = img
    return np.asarray(Image.fromarray(np.clip(g,0,255).astype("uint8")).resize((32,32), Image.LANCZOS), dtype=np.float64)

def _dct2(a):
    N=a.shape[0]; n=np.arange(N); k=n.reshape((N,1))
    C=np.cos(np.pi*(2*n+1)*k/(2*N)); return C@a@C.T

def phash(img, hs=8):
    d=_dct2(_to_gray_32(img)); block=d[:hs,:hs]
    med=np.median(block[1:].flatten()); bits=(block>med).flatten()
    val=0
    for b in bits: val=(val<<1)|int(b)
    return "phash:"+format(val,"0{}x".format((hs*hs+3)//4))

def hamming(a,b): return bin(int(a.split(':',1)[1],16) ^ int(b.split(':',1)[1],16)).count("1")

RECOVERY_THRESHOLD = 8

def main():
    if len(sys.argv) != 3:
        print("usage: python3 naked_frame_verify.py <frame_image> <record.json>"); sys.exit(2)
    frame_path, rec_path = sys.argv[1], sys.argv[2]
    with open(rec_path) as f: rec = json.load(f)
    raw = open(frame_path, "rb").read()
    img = np.asarray(Image.open(frame_path).convert("RGB"))
    cand_ph = phash(img); cand_sha = sha256_bytes(raw)
    dist = hamming(rec["phash"], cand_ph)
    bit_exact = (cand_sha == rec["sha256"])
    recovered = dist <= RECOVERY_THRESHOLD

    print("="*60)
    print("  CONTINUUM · NAKED FRAME VERIFICATION  (offline)")
    print("="*60)
    print(f"  file:                {frame_path}")
    print(f"  perceptual distance: {dist}  (recovery threshold {RECOVERY_THRESHOLD})")
    print(f"  bit-exact to sealed: {bit_exact}")
    print("-"*60)
    if not recovered:
        print("  VERDICT: NO MATCH")
        print("  These pixels do not correspond to any sealed frame.")
        print("="*60); return
    print("  VERDICT:", "IDENTICAL TO SEALED ORIGINAL" if bit_exact else "SAME IMAGE, RE-ENCODED (provenance holds)")
    print("-"*60)
    print("  PROVENANCE, RECOVERED FROM PIXELS ALONE:")
    print(f"    shot:          {rec.get('shot','-')}")
    print(f"    owned sources: {', '.join(rec.get('owned_sources',[])) or '-'}")
    print(f"    approvals:     {', '.join(rec.get('approvals',[])) or '-'}")
    print(f"    consent:       {rec.get('consent','-')}")
    print(f"    AI involved:   {rec.get('ai_involved','-')}")
    print("-"*60)
    print("  No metadata was used. No network was contacted.")
    print("  The record was recovered from the image bytes themselves.")
    print("="*60)

if __name__ == "__main__":
    main()
